﻿Public Class Form1
    ' Karakter substitusi sesuai gambar
    Private originalChars As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890.,"
    Private substituteChars As String = "BF1KQGATPJ6HYD2X5MV7C84I9NREU3LSW,.OZ0"

    ' Fungsi untuk mengenkripsi teks menggunakan substitusi
    Private Function Encrypt(ByVal text As String) As String
        Dim encryptedText As String = ""
        For Each ch As Char In text.ToUpper()
            Dim index As Integer = originalChars.IndexOf(ch)
            If index >= 0 Then
                encryptedText &= substituteChars(index)
            Else
                encryptedText &= ch ' Jika karakter tidak ada di tabel, biarkan tetap
            End If
        Next
        Return encryptedText
    End Function

    ' Fungsi untuk mendekripsi teks menggunakan substitusi
    Private Function Decrypt(ByVal encryptedText As String) As String
        Dim decryptedText As String = ""
        For Each ch As Char In encryptedText.ToUpper()
            Dim index As Integer = substituteChars.IndexOf(ch)
            If index >= 0 Then
                decryptedText &= originalChars(index)
            Else
                decryptedText &= ch ' Jika karakter tidak ada di tabel, biarkan tetap
            End If
        Next
        Return decryptedText
    End Function

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
    End Sub

    Private Sub NewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripMenuItem.Click
        MsgBox("Do you want to save changes.....", MsgBoxStyle.YesNoCancel)
        TextBox1.Text = ""
    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click
        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim encryptedText As String = My.Computer.FileSystem.ReadAllText(OpenFileDialog1.FileName)
            TextBox1.Text = Decrypt(encryptedText) ' Dekripsi teks setelah membukanya
        End If
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim encryptedText As String = Encrypt(TextBox1.Text) ' Enkripsi teks sebelum menyimpannya
            My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, encryptedText, False)
        End If
    End Sub

    Private Sub PrintToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintToolStripMenuItem.Click
        PrintDialog1.ShowDialog()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub UndoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UndoToolStripMenuItem.Click
        TextBox1.Undo()
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyToolStripMenuItem.Click
        TextBox1.Copy()
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CutToolStripMenuItem.Click
        TextBox1.Cut()
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasteToolStripMenuItem.Click
        TextBox1.Paste()
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SelectAllToolStripMenuItem.Click
        TextBox1.SelectAll()
    End Sub

    Private Sub FontToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FontToolStripMenuItem.Click
        If FontDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            TextBox1.Font = FontDialog1.Font
        End If
    End Sub

    Private Sub ColorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorToolStripMenuItem.Click
        If ColorDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            TextBox1.ForeColor = ColorDialog1.Color
        End If
    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        MsgBox("Notepad developed by " & vbCrLf & "FatuRASDW")
    End Sub
End Class